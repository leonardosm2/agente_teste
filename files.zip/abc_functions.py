"""
Funções de negócio do teste ABC em antecipação avulsa.
Substituir pelos imports/implementações reais em produção.
"""

import pandas as pd
import numpy as np
import json


def get_data() -> pd.DataFrame:
    """
    Retorna dataframe com os dados atualizados do teste ABC.
    Mock: simula dados reais de segmentos de clientes.
    """
    np.random.seed(42)
    tipos = ["porte", "segmento", "vertical"]
    clusters = {
        "porte": ["micro", "pequeno", "medio", "grande"],
        "segmento": ["alimentacao", "moda", "eletronicos", "servicos"],
        "vertical": ["marketplace", "ecommerce", "b2b"],
    }

    rows = []
    for tipo in tipos:
        for cluster in clusters[tipo]:
            for ajuste in [0, 1, 2, 3]:
                has_rating = np.random.choice([True, False], p=[0.7, 0.3])
                rows.append({
                    "tipo_cluster": tipo,
                    "cluster": cluster,
                    "ajuste": ajuste,
                    "rating_na": not has_rating,
                    "qtd_pvs": np.random.randint(50, 5000),
                    "perf_a": round(np.random.uniform(0.8, 2.5), 4),
                    "perf_b": round(np.random.uniform(0.6, 2.0), 4),
                    "perf_c": round(np.random.uniform(0.4, 1.8), 4),
                })

    return pd.DataFrame(rows)


def fill_data(update: int, rating_na: bool, rating_not_na: bool, df: pd.DataFrame) -> pd.DataFrame:
    """
    Filtra os dados do teste ABC.

    Args:
        update: após qual ajuste de preço filtrar (0 = todos)
        rating_na: incluir clientes sem rating
        rating_not_na: incluir clientes com rating
        df: dataframe com os dados brutos

    Returns:
        DataFrame com colunas: tipo_cluster, cluster, qtd_pvs, perf_a, perf_b, perf_c
    """
    filtered = df[df["ajuste"] >= update].copy()

    if rating_na and not rating_not_na:
        filtered = filtered[filtered["rating_na"] == True]
    elif rating_not_na and not rating_na:
        filtered = filtered[filtered["rating_na"] == False]
    elif not rating_na and not rating_not_na:
        # nenhum filtro de rating selecionado — retorna vazio
        return pd.DataFrame(columns=["tipo_cluster", "cluster", "qtd_pvs", "perf_a", "perf_b", "perf_c"])

    result = (
        filtered.groupby(["tipo_cluster", "cluster"])
        .agg(
            qtd_pvs=("qtd_pvs", "sum"),
            perf_a=("perf_a", "mean"),
            perf_b=("perf_b", "mean"),
            perf_c=("perf_c", "mean"),
        )
        .reset_index()
        .round({"perf_a": 4, "perf_b": 4, "perf_c": 4})
    )

    return result


def get_policy() -> pd.DataFrame:
    """
    Retorna dataframe com a política de preços e incremento do teste.

    Returns:
        DataFrame com: tipo_cluster, cluster, inc_absoluto, inc_percentual, inc_teste
    """
    tipos = ["porte", "segmento", "vertical"]
    clusters = {
        "porte": ["micro", "pequeno", "medio", "grande"],
        "segmento": ["alimentacao", "moda", "eletronicos", "servicos"],
        "vertical": ["marketplace", "ecommerce", "b2b"],
    }

    rows = []
    for tipo in tipos:
        for cluster in clusters[tipo]:
            rows.append({
                "tipo_cluster": tipo,
                "cluster": cluster,
                "inc_absoluto": round(np.random.uniform(0.005, 0.05), 4),
                "inc_percentual": round(np.random.uniform(1.0, 15.0), 2),
                "inc_teste": round(np.random.uniform(0.5, 10.0), 2),
            })

    return pd.DataFrame(rows)


def to_json(df_policy: pd.DataFrame) -> str:
    """
    Serializa o dataframe de política com inc_teste atualizado para JSON.

    Args:
        df_policy: dataframe de política (possivelmente com ajustes aprovados)

    Returns:
        String JSON com a política atualizada
    """
    return df_policy.to_json(orient="records", indent=2, force_ascii=False)
